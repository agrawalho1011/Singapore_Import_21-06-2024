﻿using CAImportWorkflow.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CAImportWorkflow.Models
{
    public class FileEntryViewModel
    {

        public string? Id { get; set; }
        public string? FileNo { get; set; }

        [Required(ErrorMessage = "Please provide a value for container field")]
        public string? ContainerNo { get; set; }
        public string? IsEdi { get; set; }

        public string? Pol { get; set; }
        public string? Pod { get; set; }

        public string? FileType { get; set; }
        public string? Hblcount { get; set; }

       
        public string? Mblcount { get; set; }
        public string? ActualHblcount { get; set; }
        public DateTime? EtaAtPod { get; set; }
        public string? VesselName { get; set; }
        public string? ShippingLine { get; set; }
        public string? Status { get; set; }
        public string? ActivityName { get; set; }
        public DateTime? StatusCompleted { get; set; }
        public int? HblPendingCount { get; set; }
        public int? HblCompletedCount { get; set; }
        public string? ThreadName { get; set; }
        public string? AllocatedTo { get; set; }
        public string? AllocatedDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? EnterDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? DigiviewThread { get; set; }
        public DateTime? DigiviewCompletedDate { get; set; }
        public int? DigiviewPages { get; set; }
        public string? ManifestThread { get; set; }
        public DateTime? ManifestCompletedDate { get; set; }
        public string? ManifestCompleted { get; set; }
        public string? TSConnectingThread { get; set; }
        public DateTime? TsConnectingCompletedDate { get; set; }
        public string? TsConnectingCompleted { get; set; }
        public int? TsConnectingCount { get; set; }
        public int? ManifestCount { get; set; }
        public string? NoadoThread { get; set; }
        public int? NoadoCount { get; set; }
        public DateTime? NoadoCompletedDate { get; set; }
        public virtual ICollection<FileActivity>? FileActivities { get; set; }
        public virtual ICollection<HblEntry>? HblEntry { get; set; }
        public virtual ICollection<FileEntryData>? FileEntryData { get; set; }
        public virtual ICollection<FileEntryData>? HBLEntryData { get; set; }

    }
}
