﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CAImportWorkflow.Migrations
{
    public partial class ThreadRelastionCreated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropForeignKey(
            //    name: "FK_ThreadMaster_AspNetUsers_UserId",
            //    table: "ThreadMaster");

            //migrationBuilder.DropIndex(
            //    name: "IX_ThreadMaster_UserId",
            //    table: "ThreadMaster");

            //migrationBuilder.DropColumn(
            //    name: "UserId",
            //    table: "ThreadMaster");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "ThreadMaster",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ThreadMaster_UserId",
                table: "ThreadMaster",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_ThreadMaster_AspNetUsers_UserId",
                table: "ThreadMaster",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
