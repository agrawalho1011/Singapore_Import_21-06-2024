﻿namespace CAImportWorkflow.Models
{
    public class HBLEntryDataDownloadViewModel
    {
        public HBLEntryDataDownloadViewModel()
        {
            FileEntryData = new List<FileEntryData>();
        }
        public string Hblno { get; set; }
        public bool? IsDap { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public List<FileEntryData> FileEntryData { get; set; }

    }
}
