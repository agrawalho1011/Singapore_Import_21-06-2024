﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public class ActivityMapping
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string FileActivityId { get; set; }
        public string HBLActivityId { get; set; }
        public bool IsActive { get; set; } = true;

        [ForeignKey("FileActivityId")]
        public virtual ActivityMaster FileActivityMaster { get; set; }

        [ForeignKey("HBLActivityId")]
        public virtual ActivityMaster HBLActivityMaster { get; set; }
    }
}
