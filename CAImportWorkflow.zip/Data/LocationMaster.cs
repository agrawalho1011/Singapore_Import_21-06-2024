﻿namespace CAImportWorkflow.Data
{
    public class LocationMaster
    {
        public LocationMaster()
        {         
            UserLocationRelation = new HashSet<UserLocationRelation>();
            //PolLocationRelation = new HashSet<PolLocationRelation>();
        }
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string Name { get; set; } = string.Empty;       
        public bool IsActive { get; set; } = true;

        public ICollection<UserLocationRelation> UserLocationRelation { get; set; }
        //public ICollection<PolLocationRelation> PolLocationRelation { get; set; }
    }
}
