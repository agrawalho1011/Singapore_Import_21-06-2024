﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public class ThreadRelation
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string UserId { get; set; }
        public string ThreadId { get; set; }
        public bool IsActive { get; set; } = true;

        [ForeignKey("UserId")]
        public User User { get; set; }

        [ForeignKey("ThreadId")]
        public ThreadMaster ThreadMaster { get; set; }

    }
}
