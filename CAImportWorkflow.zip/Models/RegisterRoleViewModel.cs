﻿namespace CAImportWorkflow.Models
{
    public class RegisterRoleViewModel
    {
        public string? Id { get; set; }
        public string Name { get; set; }
        public string? NormalizedName { get; set; }
        public bool? IsActive { get; set; } 
        public bool? IsDelete { get; set; }
    }
}
