﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public class UserLocationRelation
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string UserId { get; set; }
        public string LocationId { get; set; }
        public int? Sequence { get; set; } = 999;

        [ForeignKey("UserId")]
        public User User { get; set; }

        [ForeignKey("LocationId")]
        public LocationMaster LocationMaster { get; set; }
    }
}
