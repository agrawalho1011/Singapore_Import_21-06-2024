﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace CAImportWorkflow.Data
{
    public partial class HblActivity
    {
       
        public string Id { get; set; }
        public string HblId { get; set; }
        public string ActivityId { get; set; }
        public string CurrentStatus { get; set; }
        public string? Comment { get; set; }
        public string? EnterBy { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? EnterDate { get; set; }

        [ForeignKey("HblId")]
        public virtual HblEntry HblEntry { get; set; }

        [ForeignKey("ActivityId")]
        public virtual ActivityMaster ActivityMaster { get; set; }

        [ForeignKey("EnterBy")]
        public virtual User User { get; set; }
        public virtual ICollection<HBLHistoryLog> HBLHistoryLog { get; set; }

    }
}
