﻿namespace CAImportWorkflow.Models
{
    public class UpdateLocationModel
    {
        public string? UserId { get; set; }
        public List<LocationList>? LocationList { get; set; }
    }

    public class LocationList
    {
        public string? LocationId { get; set; }
    }
}
