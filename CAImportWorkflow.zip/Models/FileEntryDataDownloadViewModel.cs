﻿namespace CAImportWorkflow.Models
{
    public class FileEntryDataDownloadViewModel
    {
        public FileEntryDataDownloadViewModel()
        {
            FileEntryData = new List<FileEntryData>();
        }
        public string FileNo { get; set; }
        public string ContainerNo { get; set; }
        public string IsEdi { get; set; }
        public string Pol { get; set; }
        public string Pod { get; set; }
        public string FinalDestination { get; set; }
        public string FileType { get; set; }
        public string Hblcount { get; set; }
        public string Cbm { get; set; }
        public string CoLoader { get; set; }
        public string SailingDate { get; set; }
        public string EtaAtPod { get; set; }
        public string VesselName { get; set; }
        public string ShippingLine { get; set; }
        public string ContactPerson { get; set; }

        public List<FileEntryData> FileEntryData { get; set; }
       
    }
    public class FileEntryData
    {
        public string FileId { get; set; }
        public string HBLId { get; set; }
        public string Activity { get; set; }
        public DateTime? Date { get; set; }
        public string Status { get; set; }
        public string UserName { get; set; }
        public string Comment { get; set; }
    }

    public class FileDataList
    {
        public string Id { get; set; }
        public string FileNo { get; set; }
        public string ActivityId { get; set; }
        public string CurrentStatus { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? EnterDate { get; set; }
        public string UserId { get; set; }
        public string Comment { get; set; }
    }
    public class HBLDataList
    {
        public string Id { get; set; }
        public string FileGuidId { get; set; }
        public string Hblno { get; set; }
        public string? PLD { get; set; }
        public string? HBLType { get; set; }
        public bool? IsDap { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
    }

    public class FileActivityDataList
    {
        public string Id { get; set; }
        public string HBLId { get; set; }
        public string FileId { get; set; }
        public string FileNo { get; set; }
        public string ContainerNo { get; set; }
        public string hblNo { get; set; }
        public string Activity { get; set; }
        public string ActivityId { get; set; }
        public string BasedOn { get; set; }
        public string? HBLType { get; set; }
        public string? IsEdi { get; set; }
        public int? Pages { get; set; }
        public string CurrentStatus { get; set; }
        public string? Remarks { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? Eta { get; set; }
        public DateTime? EnterDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? StartTime { get; set; }
        public string UserId { get; set; }
        public string Comment { get; set; }
        public string hblCount { get; set; }
    }
    public class HBLActivityDataList
    {
        public string Id { get; set; }
        public string FileGuidId { get; set; }
        public string HBLId { get; set; }
        public string Hblno { get; set; }
        public string? HBLType { get; set; }
        public string ActivityId { get; set; }
        public string Activity { get; set; }
        public string? IsDap { get; set; }
        public string CreatedBy { get; set; }
        public string BasedOn { get; set; }
        public string Comment { get; set; }
        public string CurrentStatus { get; set; }
        public DateTime? StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public DateTime? Eta { get; set; }
        public string EnterBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
